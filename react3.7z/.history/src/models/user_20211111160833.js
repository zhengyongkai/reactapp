export default {
    namespace: 'count', // 默认与文件名相同
    state: {
        userInfo: {}
    },
    subscriptions: {
        setup({ dispatch, history }) {

        },
    },
    reducers: {
        update(state) {
            return `${state}_count`;
        },
        setUserInfo(state, { payload }) {

            console.log(payload)

            return state;
        }
    },
    effects: {
        *fetch({ type, payload }, { put, call, select }) {
            yield put({ type: 'add', payload: payload.count });
        },
        *login({ type, payload }, { put, call, select }) {
            yield put({ type: 'setUserInfo', payload })
        }
    },
}