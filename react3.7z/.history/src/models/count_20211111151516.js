export default {
    namespace: 'count', // 默认与文件名相同
    state: 'count',
    subscriptions: {
      setup({ dispatch, history }) {
        
      },
    },
    reducers: {
      update(state) {
        return `${state}_count`;
      },
    },
    effects: {
      *fetch({ type, payload }, { put, call, select }) {
      },
    },
}