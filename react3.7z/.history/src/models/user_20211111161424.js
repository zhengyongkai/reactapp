export default {
    namespace: 'user', // 默认与文件名相同
    state: {
        userInfo: {}
    },
    subscriptions: {
        setup({ dispatch, history }) {

        },
    },
    reducers: {
        update(state) {
            return `${state}_count`;
        },
        setLogged(state, { payload }) {

            console.log(payload)

            return state;
        }
    },
    effects: {
        *fetch({ type, payload }, { put, call, select }) {
            yield put({ type: 'add', payload: payload.count });
        },
        *SET_LOGGED({ type, payload }, { put, call, select }) {
        
            yield put({ type: 'setLogged', payload })
        }
    },
}