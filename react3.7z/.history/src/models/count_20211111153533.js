export default {
  namespace: 'count', // 默认与文件名相同
  state: {
    record: 0,
    current: 0,
  },
  subscriptions: {
    setup({ dispatch, history }) {

    },
  },
  reducers: {
    update(state) {
      return `${state}_count`;
    },
    add(state, { payload }) {

      return state.record + payload;
    }
  },
  effects: {
    *fetch({ type, payload }, { put, call, select }) {
      return yield put({ type: 'add', payload: payload.count });
    },
  },
}