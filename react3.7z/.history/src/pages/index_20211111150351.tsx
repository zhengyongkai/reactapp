import { useState } from 'react';
import styles from './index.less';
import { Button } from 'antd-mobile-v5'
export default function IndexPage() {
  let [num, setNum] = useState(0);
  return (
    <div>
      <h1 className={styles.title}>{num}</h1>
      <Button color='primary'>Primary</Button>
    </div>
  );
}
