import React, { useState } from 'react';
import styles from './index.less';
import { Button } from 'antd-mobile-v5'
import { connect } from 'dva'


const IndexPage: React.FC = (props) => {
  let [num, setNum] = useState(0);
  return (
    <div>
      <Button
        onClick={() => {
          alert(props.count)
        }}
      >
        Default
          </Button>
      <h1 className={styles.title}>{num}</h1>
      <Button color='primary'>Primary</Button>
    </div>
  );
}

export default connect(({ count }) => ({ count }))(IndexPage);  
