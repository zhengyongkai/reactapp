import React, { useState } from 'react';
import styles from './index.less';
import { Button } from 'antd-mobile-v5'
import { connect } from 'dva'
import { saveMessage } from '@/service/countAjax'
function mapStateToProps(state: any) {
  const { record, current } = state.count // test就是models命名空间名字 
  return {
    record, // 在这return,上面才能获取到
    current
  }
}
const IndexPage: React.FC = (props: any) => {
  let [num, setNum] = useState(0);

  return (
    <div>
      <Button
        onClick={() => {
          saveMessage({ appType:'Manage',passWord:'Foxconn99',workNo:'F1700371' }).then(({ res }) => {
            console.log(res)
          })
        }}
      >
        Default
          </Button>
      { props.record}
      {props.current}
      <h1 className={styles.title}>{num}</h1>
      <Button color='primary'>Primary</Button>
    </div>
  );
}

export default connect(mapStateToProps)(IndexPage);
