import React, { useState } from 'react';
import styles from './index.less';
import { Button } from 'antd-mobile-v5'
import { connect } from 'dva'

function mapStateToProps (state:any) {
  const { num} = state.count // test就是models命名空间名字 
  return {
      num, // 在这return,上面才能获取到
  }
}
const IndexPage: React.FC = (props: any) => {
  let [num, setNum] = useState(0);

  return (
    <div>
      <Button
        onClick={() => {
          props.dispatch({
            type: 'count/fetch', payload: {
              count: 10
            }
          })

        }}
      >
        Default
          </Button>
      { props.count.record }
      <h1 className={styles.title}>{num}</h1>
      <Button color='primary'>Primary</Button>
    </div>
  );
}

export default connect(mapStateToProps)(IndexPage);
