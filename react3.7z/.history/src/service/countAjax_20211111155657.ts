import  request  from '@/utils/request'

export async function saveMessage(data: any) {
    return request('/api/staff/bgsurvey', {
      method: 'POST',
      data: data,
    });
  }
  