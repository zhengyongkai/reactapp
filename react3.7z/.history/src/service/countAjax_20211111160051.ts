import  request  from '@/utils/request'

export async function saveMessage(data: any) {
    return request('/api/admin/auth/login', {
      method: 'POST',
      data: data,
    });
  }
  