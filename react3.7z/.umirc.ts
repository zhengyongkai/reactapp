import { defineConfig } from 'umi';

export default defineConfig({
  nodeModulesTransform: {
    type: 'none',
  },
  routes: [
    { path: '/', component: '@/pages/index' },
  ],
  fastRefresh: {},
  proxy: {
    '/api': {
      target: 'http://demo.fsc.foxconn.com:8100',
      pathRewrite: { '^/api': '' },
      changeOrigin: true
    }
  }
});
