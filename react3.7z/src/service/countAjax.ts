import  request  from '@/utils/request'

export async function saveMessage(data: any) {
    return request('/api/admin/auth/login', {
      method: 'POST',
      data: data,
      requestType: 'form'  //加个这个，就可以了
    });
  }
  