import { setStore } from '@/utils/storage'
export default {
    namespace: 'user', // 默认与文件名相同
    state: {
        userInfo: {}
    },
    subscriptions: {
        setup({ dispatch, history }) {

        },
    },
    reducers: {
        update(state) {
            return `${state}_count`;
        },
        setLogged(state, { payload }) {


            return state;
        }
    },
    effects: {
        *fetch({ type, payload }, { put, call, select }) {
            yield put({ type: 'add', payload: payload.count });
        },
        *SET_LOGGED({ type, payload }, { put, call, select }) {
            setStore('tokenList', data.tokenList);
            setStore('refreshToken', data.refreshToken);
            setStore('expireIn', data.expireIn);
            setStore('clientId', data.clientId);
            setStore('logged', true);
            yield put({ type: 'setLogged', payload })
        }
    },
}